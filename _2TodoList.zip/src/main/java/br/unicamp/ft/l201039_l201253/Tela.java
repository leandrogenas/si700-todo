package br.unicamp.ft.l201039_l201253;

public class Tela {

    public static final int LOGIN = 1;
    public static final int NOVO_TODO = 2;
    public static final int LISTAR_TODO = 3;

}
