package br.unicamp.ft.l201039_l201253;

public class User {
}
